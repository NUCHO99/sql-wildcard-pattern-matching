# sql-wildcard-pattern-matching
SQL pattern matching using LIKE, %, and _ wildcards
